---
title: "Topic 1 is very cool!"
date: 2019-06-17T23:53:00+01:00
draft: true
hideLastModified: true
summary: "The summary image should be a custom one"
summaryImage: "summary.jpg"
tags: ["custom_image", "custom_summary"]
---

This is the real text of the article. 