---
title: "Subtopic 3 is very cool!"
date: 2019-06-17T23:53:00+01:00
draft: true
hideLastModified: true
tags: ["no_summary", "code"]
---

This is the real text of the article. 

```python
def sum_function(a, b):
    c = a + b
    return c
```