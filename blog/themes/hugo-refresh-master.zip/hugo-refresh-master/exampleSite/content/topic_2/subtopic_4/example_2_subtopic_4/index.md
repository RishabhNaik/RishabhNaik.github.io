---
title: "Example 2 of subtopic 4"
date: 2019-06-17T23:53:00+01:00
draft: true
hideLastModified: true
tags: ["no_summary", "default_image", "leaf_bundle"]
---

This summary is the real content of the article. 